from xgboost import XGBRegressor
print("XGBoost is working")